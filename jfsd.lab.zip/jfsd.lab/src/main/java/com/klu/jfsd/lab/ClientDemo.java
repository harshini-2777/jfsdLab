package com.klu.jfsd.lab;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientDemo {
    public static void main(String[] args) {
        // Create SessionFactory
        SessionFactory factory = new Configuration().configure().buildSessionFactory();

        // Insert records
        try (Session session = factory.openSession()) {
            Transaction tx = session.beginTransaction();

            // Vehicle object
            Vehicle vehicle = new Vehicle() {
                { // Inline initialization
                    setName("Generic Vehicle");
                    setType("General");
                    setMaxSpeed(100);
                    setColor("White");
                }
            };

            // Car object
            Car car = new Car();
            car.setName("Honda Civic");
            car.setType("Sedan");
            car.setMaxSpeed(220);
            car.setColor("Red");
            car.setNumberOfDoors(4);

            // Truck object
            Truck truck = new Truck();
            truck.setName("Volvo FH");
            truck.setType("Heavy");
            truck.setMaxSpeed(120);
            truck.setColor("Blue");
            truck.setLoadCapacity(2000);

            // Save records
            session.save(vehicle);
            session.save(car);
            session.save(truck);

            tx.commit();
        }

        System.out.println("Records inserted successfully!");
        factory.close();
    }
}

