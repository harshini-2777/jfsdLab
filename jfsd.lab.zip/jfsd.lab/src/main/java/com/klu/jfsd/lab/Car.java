package com.klu.jfsd.lab;

public class Car {

}
